#include<stdio.h>
main()
{char s[100];
 int c,i;
 scanf("%c",&c);
 scanf("%d",&i);
 scanf("%s",s);   //输出
 printf("%c,%d,%s\n",c,i,s);




}
