In 2017, the worst hurricane to ever hit the United States territory of Puerto Rico 
(see Attachment 1) left the island with severe damage and caused over 2900 fatalities. The 
combined destructive power of the hurricane’s storm surge and wave action produced extensive 
damage to buildings, homes, and roads, particularly along the east and southeast coast of Puerto 
Rico.